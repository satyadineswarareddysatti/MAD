import 'event.dart';
import 'stats.dart';

// Abstract base class for processes
abstract class Process {
  String name; // Name of the process
  List<Event> completedEvents = []; // List to store completed events

  Process(this.name); // Constructor

  List<Event> generateEvents(); // Abstract method to generate events
}

// SingletonProcess class extends Process
class SingletonProcess extends Process {
  int arrival; // Arrival time of the event
  int duration; // Duration of the event

  // Constructor
  SingletonProcess(String name, Map<String, dynamic> config)
      : arrival = config['arrival'],
        duration = config['duration'],
        super(name);

  // Override generateEvents method
  @override
  List<Event> generateEvents() {
    // Return a list with a single event
    return [Event(name, arrival, duration)];
  }
}

// PeriodicProcess class extends Process
class PeriodicProcess extends Process {
  int firstArrival; // First arrival time
  int duration; // Duration of each event
  int interarrivalTime; // Time between event arrivals
  int numRepetitions; // Number of event repetitions

  // Constructor
  PeriodicProcess(String name, Map<String, dynamic> config)
      : firstArrival = config['first-arrival'],
        duration = config['duration'],
        interarrivalTime = config['interarrival-time'],
        numRepetitions = config['num-repetitions'],
        super(name);

  // Override generateEvents method
  @override
  List<Event> generateEvents() {
    List<Event> events = []; // List to store generated events
    for (int i = 0; i < numRepetitions; i++) {
      // Add events to the list based on the configuration
      events.add(Event(name, firstArrival + i * interarrivalTime, duration));
    }
    return events;
  }
}

// StochasticProcess class extends Process
class StochasticProcess extends Process {
  ExpDistribution durationDist; // Distribution for event durations
  ExpDistribution interarrivalDist; // Distribution for event interarrival times
  int firstArrival; // First arrival time
  int end; // End time of the process

  // Constructor
  StochasticProcess(String name, Map<String, dynamic> config)
      : durationDist =
            ExpDistribution(mean: (config['mean-duration'] as num).toDouble()),
        interarrivalDist = ExpDistribution(
            mean: (config['mean-interarrival-time'] as num).toDouble()),
        firstArrival = config['first-arrival'],
        end = config['end'],
        super(name);

  // Override generateEvents method
  @override
  List<Event> generateEvents() {
    List<Event> events = []; // List to store generated events
    int arrivalTime = firstArrival; // Initialize arrival time
    while (arrivalTime < end) {
      final duration = durationDist.sample().round(); // Generate event duration
      events.add(Event(name, arrivalTime, duration)); // Add event to the list
      arrivalTime += (interarrivalDist.sample() / 2)
          .round(); // Generate interarrival time and update arrival time
    }
    return events;
  }
}
