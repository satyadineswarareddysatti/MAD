import 'dart:math';
import 'process.dart';
import 'event.dart';

class Simulation {
  Map<String, dynamic> config; // Configuration map
  bool verbose; // Flag to control verbose output
  List<Event> eventQueue = []; // Queue to store events
  Map<String, Process> processes = {}; // Map to store processes

  // Constructor
  Simulation(this.config, [this.verbose = false]);

  void run() {
    config.forEach((name, procConfig) {
      Process proc; // Variable to store the process instance
      switch (procConfig['type']) {
        case 'singleton':
          proc = SingletonProcess(name, procConfig); // Create SingletonProcess
          break;
        case 'periodic':
          proc = PeriodicProcess(name, procConfig); // Create PeriodicProcess
          break;
        case 'stochastic':
          proc =
              StochasticProcess(name, procConfig); // Create StochasticProcess
          break;
        default:
          throw Exception('Unknown process type: ${procConfig['type']}');
      }
      processes[name] = proc; // Store the process in the processes map
      eventQueue
          .addAll(proc.generateEvents()); // Add generated events to the queue
    });

    eventQueue.sort((a, b) =>
        a.arrivalTime.compareTo(b.arrivalTime)); // Sort events by arrival time

    int currentTime = 0; // Initialize current simulation time
    while (eventQueue.isNotEmpty) {
      final event =
          eventQueue.removeAt(0); // Remove the first event from the queue
      currentTime = max(currentTime, event.arrivalTime); // Update current time
      event.startTime = currentTime; // Set the start time of the event
      event.waitTime =
          event.startTime - event.arrivalTime; // Calculate wait time
      currentTime += event.duration; // Update current time with event duration
      processes[event.processName]
          ?.completedEvents
          .add(event); // Add the event to completed events

      if (verbose) {
        print(
            't=$currentTime: ${event.processName}, duration ${event.duration} '
            'started (arrived @ ${event.arrivalTime}, waited ${event.waitTime})');
      }

      // Introduce a delay to simulate processing time
      if (eventQueue.isNotEmpty) {
        final nextEvent = eventQueue.first; // Get the next event
        if (nextEvent.arrivalTime < currentTime) {
          nextEvent.waitTime = currentTime -
              nextEvent.arrivalTime; // Update wait time of the next event
        }
      }
    }
  }

  void printReport() {
    if (verbose) {
      print(
          '\n--------------------------------------------------------------\n');
    }

    print('# Per-process statistics\n');
    processes.forEach((name, process) {
      final events =
          process.completedEvents; // Get completed events of the process
      final totalWait = events.fold(
          0, (acc, e) => acc + e.waitTime); // Calculate total wait time
      final avgWait = events.isNotEmpty
          ? totalWait / events.length
          : 0; // Calculate average wait time

      print('$name:');
      print('  Events generated:  ${events.length}');
      print('  Total wait time:   $totalWait');
      print('  Average wait time: ${avgWait.toStringAsFixed(2)}\n');
    });

    print('--------------------------------------------------------------\n');
    print('# Summary statistics\n');

    final totalEvents = processes.values.fold(0,
        (acc, p) => acc + p.completedEvents.length); // Calculate total events
    final totalWait = processes.values.fold(
        0,
        (acc, p) =>
            acc +
            p.completedEvents.fold(
                0, (acc, e) => acc + e.waitTime)); // Calculate total wait time
    final avgWait = totalEvents > 0
        ? totalWait / totalEvents
        : 0; // Calculate average wait time

    print('Total num events:  $totalEvents');
    print('Total wait time:   ${totalWait.toStringAsFixed(2)}');
    print('Average wait time: ${avgWait.toStringAsFixed(3)}');
  }
}
