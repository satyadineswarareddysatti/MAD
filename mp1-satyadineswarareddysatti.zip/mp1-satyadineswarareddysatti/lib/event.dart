class Event {
  String processName; // Name of the process
  int arrivalTime; // Arrival time of the event
  int startTime = 0; // Start time of the event (initialized to 0)
  int duration; // Duration of the event
  int waitTime = 0; // Wait time of the event (initialized to 0)

  // Constructor
  Event(this.processName, this.arrivalTime, this.duration);
}
