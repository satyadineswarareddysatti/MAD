import 'dart:math';

class ExpDistribution {
  double mean; // Mean of the exponential distribution
  Random _random = Random(); // Random number generator

  // Constructor
  ExpDistribution({required this.mean});

  // Method to generate a random sample from the exponential distribution
  double sample() {
    return -mean * log(1 - _random.nextDouble());
  }
}
