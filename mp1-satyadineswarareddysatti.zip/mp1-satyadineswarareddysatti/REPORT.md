# MP Report

## Team

- Name: Satya dineswara reddy satti
- AID: A20528639

## Self-Evaluation Checklist

Tick the boxes (i.e., fill them with 'X's) that apply to your submission:

- [X] The simulator builds without error
- [X] The simulator runs on at least one configuration file without crashing
- [X] Verbose output (via the `-v` flag) is implemented
- [X] I used the provided starter code
- The simulator runs correctly (to the best of my knowledge) on the provided configuration file(s):
  - [X] conf/sim1.yaml
  - [X] conf/sim2.yaml
  - [X] conf/sim3.yaml
  - [X] conf/sim4.yaml
  - [X] conf/sim5.yaml

## Summary and Reflection

1)  During the implementation of this queueing simulator, I made some notable decisions to ensure code modularity, readability, and adherence to the requirements.Firstly, I structured the code into separate classes for Simulation, Process, and Event, each with its own responsibilities. This modular design allowed for easier testing and maintenance of the codebase.I utilized the provided ExpDistribution class for generating random samples from the exponential distribution, which simplified the implementation of the stochastic process.To handle the different process types (singleton, periodic, and stochastic), I created subclasses of the Process class, each with its own logic for generating events based on the specified configuration.I implemented the Simulation class with a run method that iterates over the combined event queue, sorted by arrival time. This approach ensured that events were processed in the correct order, and the start and wait times were updated accordingly.For reporting purposes, I stored the processed events in their respective Process objects, making it easier to calculate per-process statistics.I also added a verbose flag that, when set, generates a detailed simulation trace, which helped in debugging and verifying the correctness of the simulation.One challenge I faced was ensuring the accuracy of the simulation results, especially for the stochastic processes. To overcome this, I performed multiple test runs and compared the results with the expected summary statistics provided in the configuration files. While there might be slight variations due to the randomness introduced by the stochastic processes, the overall results align with the expected outcomes.I thoroughly tested the simulator with the provided configuration files and made sure that the outputs matched the expected format and statistics. The simulator correctly processes the configuration files, generates events based on the specified process types, and produces accurate simulation traces and statistics.Overall, I am confident that the implemented queueing simulator meets all the requirements and functions as expected. However, if there are any areas that require further clarification or improvement, I am open to feedback and suggestions.

2) Working on this queueing simulator MP was an engaging and challenging experience. I enjoyed the opportunity to apply my knowledge of queueing systems and discrete-event simulation to a practical implementation.One aspect I particularly enjoyed was designing the modular structure of the code, with separate classes for Simulation, Process, and Event. This allowed me to organize the code logically and made it easier to understand and maintain.I found it challenging to ensure the accuracy of the simulation results, especially when dealing with stochastic processes. It required careful testing and validation against the expected statistics to ensure that the simulator was functioning correctly.Another challenge was handling the different process types and their specific configurations. Implementing the logic for generating events based on the process type and the provided configuration required a good understanding of the problem domain and attention to detail.Before starting this MP, I wish I had a better understanding of the exponential distribution and its role in modeling stochastic processes. It would have saved me some time in researching and understanding how to generate random samples from the exponential distribution.Overall, this MP provided a valuable learning experience in implementing a queueing simulator and reinforced my understanding of queueing systems and discrete-event simulation. It also helped me improve my skills in designing modular code and handling different process types and configurations.